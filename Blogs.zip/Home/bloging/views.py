from django.shortcuts import render, redirect
from .models import Post
from .forms import PostForm
from django.http import Http404


def home(request):
	data = Post.objects.all()[::-1]
	return render(request, 'bloging/home.html', context={'data':data,})



def post_list(request):
	info = Post.objects.all()
	return render(request, 'bloging/allpost.html', {'Info': info})




def details(request,slug):
    try:
        text = Post.objects.get(slug=slug)
    except:
        raise Http404()
    return render(request,'bloging/post.html',
            {'title':text.title,
            'content':text.content,
            'date':text.date,
			'image':text.image})
    


def addpost(request):
	if request.method =='POST':
		form = PostForm(request.POST,request.FILES)
		if form.is_valid():
			form.save()
			return redirect('home_page')
	else:
		form = PostForm()
	return render(request,'bloging/add.html',{'form':form})

