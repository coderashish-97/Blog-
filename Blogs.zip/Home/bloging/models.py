from django.db import models
from django.utils.text import slugify
from django.urls import reverse



class Author(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(max_length = 254)
    
def __str__(self):
    return f"{self.first_name} {self.last_name}"

class Tag(models.Model):
    tag=models.CharField(max_length=20)

def __str__(self):
    return self.tag


class Post(models.Model):
    title=models.CharField(max_length=20)
    content = models.TextField()
    image = models.ImageField(upload_to='products/',null=True,blank=True)
    date=models.DateField()
    author=models.ForeignKey('Author',on_delete=models.CASCADE)
    tag=models.ManyToManyField(Tag)
    slug = models.SlugField(max_length=50,unique=True,default="",editable=True)



    def get_absolute_url(self):
        return reverse("post-detail", args=[self.slug])


    def save(self,*args, **kwargs):
        self.slug =slugify(self.title)
        super().save(*args,**kwargs)


    def __str__(self):
        return f"{self.title}{self.content}and age {self.date}"
    



















