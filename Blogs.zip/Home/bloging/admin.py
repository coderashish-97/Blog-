from django.contrib import admin
from .models import Post,Author,Tag


class PostAdmin(admin.ModelAdmin):
    list_display = ('title', 'slug', 'author','date')
    list_filter = ("title",)
    prepopulated_fields = {'slug': ('title',)}
    search_fields = ['title', 'content']



admin.site.register(Post, PostAdmin)
admin.site.register(Author)
admin.site.register(Tag)

