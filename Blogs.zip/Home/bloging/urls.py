from django.urls import path
from . import views


urlpatterns = [
    path('',views.home, name='home_page'),
	path('postlist/', views.post_list, name='list'),
    path('addpost/', views.addpost, name='new_post'),
    path('<slug:slug>',views.details,name='post-detail')]
